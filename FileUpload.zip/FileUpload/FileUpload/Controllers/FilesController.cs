﻿using FileUpload.Models;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace FileUpload.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class FilesController : ControllerBase
    {

        [HttpPost]
        [Route("UploadFiles")]
        public async Task<IActionResult> UploadFiles([FromForm] Post post)
        {
            if (post.DeletedFiles != null && post.DeletedFiles.Count > 0)
            {
                foreach (var file in post.DeletedFiles)
                {
                    string path = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot/Files");
                    string fileNameWithPath = Path.Combine(path, file);
                    if (System.IO.File.Exists(fileNameWithPath))
                    {
                        // If file found, delete it    
                        System.IO.File.Delete(fileNameWithPath); 
                    }
                }
            }

            if (post.files != null && post.files.Count > 0)
            {
                foreach (var file in post.files)
                {

                    string path = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot/Files");

                    //create folder if not exist
                    if (!Directory.Exists(path))
                        Directory.CreateDirectory(path);


                    string fileNameWithPath = Path.Combine(path, file.FileName);

                    using (var stream = new FileStream(fileNameWithPath, FileMode.Create))
                    {
                        file.CopyTo(stream);
                    }
                }

            }

            return Ok();
        }
        [HttpGet]
        [Route("GetBase64StringOfImage")]
        public async Task<object> GetBase64StringOfImage(string name)
        {
            string path = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot/Files");
            string fileNameWithPath = Path.Combine(path, name);
            byte[] imageBytes = System.IO.File.ReadAllBytes(fileNameWithPath);
            var base64Img = new Base64Image
            {
                FileContents = imageBytes,
                ContentType = "image/png"
            };

            string base64EncodedImg = base64Img.ToString();
            return base64EncodedImg;
        }

        [HttpGet, DisableRequestSizeLimit]
        [Route("getPhotos")]
        public IActionResult GetPhotos()
        {
            try
            {
                var folderName = Path.Combine("wwwroot", "Files");
                var pathToRead = Path.Combine(Directory.GetCurrentDirectory(), folderName);
                //var pathToRead = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot/Files");
                var photos = Directory.EnumerateFiles(pathToRead)
                    .Where(IsAPhotoFile)
                    .Select(fullPath => Path.GetFileName(fullPath));
                return Ok(photos);


            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex}");
            }
        }

        private bool IsAPhotoFile(string fileName)
        {
            return fileName.EndsWith(".jpg", StringComparison.OrdinalIgnoreCase)
                || fileName.EndsWith(".jpeg", StringComparison.OrdinalIgnoreCase)
                || fileName.EndsWith(".png", StringComparison.OrdinalIgnoreCase);
        }
    }
}
