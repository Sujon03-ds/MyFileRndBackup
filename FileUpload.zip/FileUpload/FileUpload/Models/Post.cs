﻿using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FileUpload.Models
{
    public class Post
    {
        public string Name { get; set; }
        public List<string> DeletedFiles { get; set; }
        public IFormFileCollection files { get; set; }
    }
}
